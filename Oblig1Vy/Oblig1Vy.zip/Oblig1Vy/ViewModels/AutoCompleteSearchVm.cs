﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Oblig1Vy.ViewModels
{
    public class AutoCompleteSearchVm
    {
        public int StationId { get; set; }
        public string StationName { get; set; }
    }
}